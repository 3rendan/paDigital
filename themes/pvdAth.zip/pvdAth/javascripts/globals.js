
$(()=> {

// $(`#lightbox`).click(function() {
// //   alert(localAccession);
// //   $('#imagepreview').attr('src', $('#imageresource').attr('src')); 
//   $('#imageModal').show(); 
// });




});
