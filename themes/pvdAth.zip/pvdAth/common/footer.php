      </div>
    </main>
    <footer class="ath-foot" role="contentinfo">
            <div class="row footer-info">
                <a href="http://providenceathenaeum.org">The Providence Athenæum</a>               
                <p>251 Benefit St. Providence RI 02903 <br>401 421-6970</p>
            </div>            
            <div class="ath-btm">
                <p class="text-center">
                    Powered by <a href="http://omeka.org" style='color:#fff'>Omeka</a>
                </p>
            </div>     
    </footer>
</body>
</html>
