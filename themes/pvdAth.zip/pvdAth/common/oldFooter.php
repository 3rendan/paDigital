      </div>
    </main>
    <footer class="ath-foot noPrint" role="contentinfo">
        <div class="row">
            <img src="/uploads/squareWordmark.png" alt="">
            <p style="text-align: center;font-family: 'EB Garamond', serif;font-size: 1.25em;">251 Benefit St. Providence RI 02903</p>
            <!--<div class="col-md-6 col-sm-12"  style="border-right: .05em solid #d5d5d5;">
                TEXT COLOR THERE TO ACCOUNT FOR SAFARI MISBEHAVING IN ALIGNING
                <div class="col-lg-3 col-md-3" style="color:#000">text</div>
                <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="footer-athena">
                    <img src="//providenceathenaeum.org/wp-content/uploads/dynamik-gen/theme/images/athena_footer.png">
                </div></div>

                <div class="gen-info" style="margin-top: 10px;">
                    <p>&nbsp;</p>
                    Monday – Thursday: 9am to 7pm <br/>
                    Friday – Saturday: 9am to 5pm <br/>
                    Sunday: 1pm to 5pm <br/>
                    <p>&nbsp;</p>
                    401-421-6970 <br/>
                    <a href="https://goo.gl/maps/XJsVpN6z4D72" target="_blank">251 Benefit Street<br/>
                    Providence, RI 02903 </a><br/>
                    <em><a href="mailto:info@providenceathenaeum.org">info@providenceathenaeum.org </a></em>
                    <p>&nbsp;</p>
                </div>
            </div>


            <div class="col-md-6 col-sm-12">
                <div class="news"> 
                    <a href="https://providenceathenaeum.us10.list-manage.com/subscribe?u=94db8a47832f7b9a666b66a2f&id=63fa9054a4" alt="E-News" target="_blank"><img src="/themes/pvdAth/images/eNews.png" style="margin-top: 50px;margin-bottom:8px;" alt="Sign up for E-News"/></a>
                </div>-->

                <div class="row social">
                    <a href="https://www.facebook.com/ProvidenceAthenaeum?v=info&ref=nf%0A++++" target="_blank"><img class="icon1" src="/themes/pvdAth/images/fb.png" alt="Facebook"/></a>
                    <a href="https://twitter.com/pvdAth" target="_blank"><img class="icon2" src="/themes/pvdAth/images/twitter.png" alt="Twitter"/></a>
                    <a href="https://instagram.com/pvdath" target="_blank"><img class="icon3" src="/themes/pvdAth/images/instagram.png" alt="Instagram"/></a>  
                </div> 
                <div class="search-form">
                    <form class="navbar-form srch" role="search" action="/search"> 
                        <input id="query" class="form-control" name="query" value="" style="background:#666666;border:none;" placeholder="SEARCH" type="text">
                    </form>
                </div>
            </div>
        </div>

            
           
        </div>
        <div class="container ath-btm">
            <p class="text-center">
                <a href="http://providenceathenaeum.org">The Providence Athenæum</a> • Proudly powered by <a href="http://omeka.org">Omeka</a>
            </p>
        </div>
    </div>
    </footer>
</body>
</html>
