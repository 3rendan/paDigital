<?php 
    foreach ($tags as $tag) {
    echo "<button type=\"button\" class=\"btn-tags\">" . $tag . "</button>";
	}
    ?>